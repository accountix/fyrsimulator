img2=new Image();
img1=new Image();
var period;
var typ;
var timer;
var times= new Array();
var timer= new Array();
var count;
var counter;
var x, grupp, text;
var moTyp=1;


function isOdd(a)
{

    if((a/2)==(Math.floor(a/2))) return(0);
    return(1);

}

function lightState()
{
	var x=document.getElementById('lighthousePic');
	if(x.src==img1.src) return("off");
	else return("on");

}

function turnOn()
{

    var x=document.getElementById('lighthousePic');
    x.src=img2.src;

}

function turnOff()
{

    var x=document.getElementById('lighthousePic');
    x.src=img1.src;


}


function preload()
{

    img2.src="fyr2.png";	// tänd fyr
    img1.src="fyr1.png";	// släckt fyr

}

function makeISO()
{

    times[0]=period/2;
    times[1]=period/2;

    count=2;

    text="ISO "+period/10+"s";

}

function makeFL()
{
    if(period<(grupp*20)+10) 
	{ 
		alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
		return(-1);
	}

    for(a=0;a<(2*grupp)-1;a++)
	{
		times[a]=10;
	}5
    times[a]=period-(grupp*20)+10;

    count=2*grupp;

    text="Fl";
    if(grupp>1) 
	text=text+"("+grupp+")";
    text+=" "+period/10+"s";

}

function makeLFL()
{
    if(period<(grupp*50)+10) 
	{ 
		alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
		return(-1);
	}


    for(a=0;a<(2*grupp)-1;a++)
	{
		if(!isOdd(a)) 
			times[a]=40;
		else
			times[a]=10;
	}
    times[a]=period-(grupp*50)+10;

    count=2*grupp;

    return(0);
}

function makeOc()
{
    var swap;

    if(period<(grupp*20)+10) 
	{ 
		alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
		return(-1);
	}
    for(a=0;a<(2*grupp)-1;a++)	// samma algoritm som för Flash, kräver att man byter första och sista tiderna
	{
		times[a]=10;
	}
    times[a]=period-(grupp*20)+10;

    swap=times[0];		// byt sista och första tiden
    times[0]= times[a];
    times[a]=swap;

    text="Oc";
    if(grupp>1) 
	text=text+"("+grupp+")";
    text+=" "+period/10+"s";


    count=2*grupp;
    return(0);
}

function makeQ()
{
    if(period<(grupp*10)+5) 
	{ 
		alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
		return(-1);
	}

    for(a=0;a<(2*grupp)-1;a++)
	{
		times[a]=5;
	}
    times[a]=period-(grupp*10)+5;

    text="Q";
    if(grupp>1) 
	text=text+"("+grupp+")";
    text+=" "+period/10+"s";


    count=2*grupp;

    return(0);
}

function makeVQ()
{

    if(period<(grupp*4)+2) 
	{ 
		alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
		return(-1);
	}

    for(a=0;a<(2*grupp)-1;a++)
	{
		times[a]=2;
	}
    times[a]=period-(grupp*4)+2;

    text="VQ";
    if(grupp>1) 
	text=text+"("+grupp+")";
    text+=" "+period/10+"s";


    count=2*grupp;

    return(0);

}

function makeMo()
{
    switch (moTyp)
    {
        case 1:     if(period-25<10)
                        { 
                            alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
                            return(-1);
                        }
                    times[0]=5;
                    times[1]=5;
                    times[2]=15;
                    times[3]=period-25;
                    count=4;
                    text="Mo(A) "+period/10+"s";
                    return(0);
                    break;
                    
        case 2:     if(period-45<10)
                        { 
                            alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
                            return(-1);
                        }
                    times[0]=15;
                    for(a=1;a<7;a++)
                        times[a]=5;
                    times[7]=period-45;
                    times[8]=0;
                    count=8;
                    text="Mo(B) "+period/10+"s";
                    
                    return(0);
                    break;
        
        case 3:     if(period-55<10)
                        { 
                            alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
                            return(-1);
                        }
                    times[0]=15;
                    for(a=1;a<4;a++)
                        times[a]=5;
                    times[4]=15;
                    for(a=5;a<7;a++)
                        times[a]=5;
                    times[7]=period-55;
                    times[8]=0;
                    count=8;
                    text="Mo(C) "+period/10+"s";
                    
                    return(0);
                    break;
        
         case 4:     if(period-35<10)
                        { 
                            alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
                            return(-1);
                        }
                    times[0]=15;
                    for(a=1;a<5;a++)
                        times[a]=5;
                    times[5]=period-35;
                    times[6]=0;
                    count=6;
                    text="Mo(D) "+period/10+"s";
                    
                    return(0);
                    break;
          
        
    }
    

}

function makeQ6()
{
   if(period<110) 
	{ 
		alert("Den kombinationen av periodtid och grupp går inte ihop!\nAnge längre periodtid eller mindre grupp.");
		return(-1);
	}
    
    
    for(a=0;a<12;a++)
        times[a]=5;
    times[12]=40;
    times[13]=period-100;
    times[14]=0;
    
    text="Q(6)LFl "+period/10+"s";
    
    count=14;
    return(0);

}


function chooseISO()
{
    typ=1;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=true;
    obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
}

function chooseFL()
{
    typ=2;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=false;
    obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
}

function chooseLFL()
{
    typ=3;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=false;
    obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
    
}

function chooseOc()
{
    typ=4;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=false;
        obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
}

function chooseQ()
{
    typ=5;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=false;
    obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
}

function chooseVQ()
{
    typ=6;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=false;
    obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
}

function chooseMo()
{
    typ=7;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=true;

    obj=document.getElementById('bokstavA');
    obj.disabled=false;
    obj=document.getElementById('bokstavB');
    obj.disabled=false;
    obj=document.getElementById('bokstavC');
    obj.disabled=false;
    obj=document.getElementById('bokstavD');
    obj.disabled=false;
    
    
}

function chooseMoA()
{
    moTyp=1;
}

function chooseMoB()
{
    moTyp=2;
}

function chooseMoC()
{
    moTyp=3;
}

function chooseMoD()
{
    moTyp=4;
}



function chooseQ6()
{
    typ=8;

    obj=document.getElementById('fyrGrupp');
    obj.disabled=true;

    obj=document.getElementById('bokstavA');
    obj.disabled=true;
    obj=document.getElementById('bokstavB');
    obj.disabled=true;
    obj=document.getElementById('bokstavC');
    obj.disabled=true;
    obj=document.getElementById('bokstavD');
    obj.disabled=true;
    
    
}

function visaFyr()
{

    timer[counter]--;
    if(timer[counter]<=0)
	{

		var pic=lightState();
		if(pic=="off") { turnOn(); }
		else { turnOff(); }

		timer[counter]=times[counter];		// återställ tiden i matrisen
		counter++;
		if (counter==count) counter=0;		// kolla om kommit till slutet


	}

}


function skapaFyr()
{
    var fyr;

    period=document.getElementById('fyrPeriod');
    period=period.value;
    period*=10;		// omvandla till tiondelar av sekunder


    grupp=document.getElementById('fyrGrupp');
    grupp=grupp.value;

    if(grupp=="") grupp=1;		// ta hand om tom gruppruta

    switch(typ)		// skapa tidsmatrisen för fyren
	{
		case 1:		fyr=makeISO();
				break;
		case 2:		fyr=makeFL();
				break;
		case 3:		fyr=makeLFL();
				break;
		case 4:		fyr=makeOc();
				break;
		case 5:		fyr=makeQ();
				break;
		case 6:		fyr=makeVQ();
				break;
		case 7:		fyr=makeMo();
				break;
                case 8:         fyr=makeQ6();
                                break;
	}		// slut på switch

    if(fyr!=-1)	// kolla om det uppstod fel
	{
		turnOn();
		for(counter=0; counter<count;counter++) timer[counter]= times[counter];

		clearInterval(x);

		x= setInterval("visaFyr()", 100);		// anropa tio gånger per sekund
		counter=0;

		textdiv=document.getElementById('fyrtext');
		textdiv.innerHTML="Just nu visas <br>"+text;
	}
}
